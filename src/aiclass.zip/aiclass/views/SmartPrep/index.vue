<template>
  <div class="smart-prep-index">
    <router-view />
  </div>
</template>

<script>
export default {
  name: 'SmartPrepIndex'
}
</script>