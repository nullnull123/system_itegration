<template>
  <div class="note-completion-index">
    <router-view />
  </div>
</template>

<script>
export default {
  name: 'NoteCompletionIndex'
}
</script>