<template>
  <div class="exercise-assessment-index">
    <router-view />
  </div>
</template>

<script>
export default {
  name: 'ExerciseAssessmentIndex'
}
</script>